<template>
  <div>
    <nav>
      <router-link to="/">Calculator</router-link>
      <router-link to="/history">History</router-link>
      <router-link to="/settings">Settings</router-link>
    </nav>
    <router-view />
  </div>
</template>

<script>
export default {
  data() {
    return {
      history: [],
    };
  },
  methods: {
    updateHistory(entry) {
      this.history.push(entry);
    },
    resetHistory() {
      this.history = [];
    },
  },
};
</script>

<style>
nav {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-bottom: 20px;
}
nav a {
  text-decoration: none;
  color: #007bff;
  font-size: 1.2rem;
}
nav a.router-link-exact-active {
  font-weight: bold;
  color: #0056b3;
}
</style>
