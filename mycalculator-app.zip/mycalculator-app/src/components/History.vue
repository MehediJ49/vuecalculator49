<template>
    <div class="history">
      <h2>Calculation History</h2>
      <ul>
        <li v-for="entry in history" :key="entry">{{ entry }}</li>
      </ul>
      <button @click="resetHistory">Reset History</button>
    </div>
  </template>
  
  <script>
  export default {
    props: ['history'],
    methods: {
      resetHistory() {
        this.$emit('reset-history');
      },
    },
  };
  </script>
  