<template>
    <div class="calculator">
      <div class="display">{{ currentInput }}</div>
      <div class="buttons">
        <button @click="appendNumber(num)" v-for="num in numbers" :key="num">{{ num }}</button>
        <button @click="chooseOperation(op)" v-for="op in operations" :key="op">{{ op }}</button>
        <button @click="appendPoint">.</button>
        <button @click="calculate">=</button>
        <button @click="clear">C</button>
        <button @click="reset">Reset</button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        currentInput: '',
        history: [],
        numbers: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0],
        operations: ['+', '-', '*', '/'],
      };
    },
    methods: {
      appendNumber(number) {
        this.currentInput += number;
      },
      appendPoint() {
        if (!this.currentInput.includes('.')) {
          this.currentInput += '.';
        }
      },
      chooseOperation(operation) {
        if (this.currentInput !== '') {
          this.currentInput += operation;
        }
      },
      calculate() {
        try {
          const result = eval(this.currentInput); // WARNING: Avoid eval in production
          this.history.push(`${this.currentInput} = ${result}`);
          this.currentInput = result.toString();
        } catch {
          this.currentInput = 'Error';
        }
      },
      clear() {
        this.currentInput = '';
      },
      reset() {
        this.currentInput = '';
        this.history = [];
      },
    },
  };
  </script>
  
  <style scoped>
  .calculator {
    max-width: 300px;
    margin: auto;
  }
  .display {
    background-color: #000;
    color: #fff;
    padding: 1rem;
    text-align: right;
    font-size: 2rem;
  }
  .buttons {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
  }
  button {
    padding: 1rem;
    font-size: 1.5rem;
  }
  </style>
  