<template>
    <div class="settings">
      <h2>Settings</h2>
      <div>
        <label>Font Size:</label>
        <button @click="changeFontSize(-1)">-</button>
        <button @click="changeFontSize(1)">+</button>
      </div>
      <div>
        <label>Theme Color:</label>
        <select @change="changeTheme" v-model="selectedColor">
          <option v-for="color in colors" :key="color" :value="color">{{ color }}</option>
        </select>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        selectedColor: 'light',
        colors: ['light', 'dark', 'blue', 'green', 'red'],
      };
    },
    methods: {
      changeFontSize(amount) {
        document.body.style.fontSize = `${parseInt(getComputedStyle(document.body).fontSize) + amount}px`;
      },
      changeTheme() {
        document.body.className = this.selectedColor;
      },
    },
  };
  </script>
  