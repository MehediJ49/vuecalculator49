import Vue from 'vue';
import router from 'vue-router';
import Calculator from '@/components/Calculator.vue';
import History from '@/components/History.vue';
import Settings from '@/components/Settings.vue';

Vue.use(router);

export default new router({
  routes: [
    { path: '/Calculator', component: Calculator },
    { path: '/history', component: History },
    { path: '/settings', component: Settings },
  ],
});
